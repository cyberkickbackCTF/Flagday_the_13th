Do I look like someone that loves to play with cryptography?!?
Yes
…
Yes I am, that’s why you couldn’t read this until you figured it out :)

Now can you get into our kickback? I think it’s easy just bring some fun and a little street smarts, oh boy you’re going to do great!

Oh wow, would you look at that, a shell, it can’t be that easy…

SSH: xxx.xxx.xxx.xxx (turn to hexa)

Now make sure to check for the “you know what file” to see what Marty wanted us to look into.

Thanks buddy!